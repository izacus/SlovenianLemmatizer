/* libmain - flex run-time support library "main" function */

/* $Header: c:\\program\040files\\development\\cvs\040repository/flex++/libmain.c,v 1.1.1.1 2002/04/13 06:01:32 Bear Exp $ */

extern int yylex();

int main( argc, argv )
int argc;
char *argv[];

    {
    return yylex();
    }
